
/* =========================================
   CONFIGURAÇÃO DOS GOOGLE FORMS
   Cole cada link entre as aspas.
========================================= */

const FORM_LINKS = {
  presence: "COLE_AQUI_LINK_FORM_PRESENCA",
  indication: "COLE_AQUI_LINK_FORM_INDICACAO",
  newMember: "COLE_AQUI_LINK_FORM_NOVO_MEMBRO"
};

function abrirFormulario(tipo) {
  const link = FORM_LINKS[tipo];

  if (!link || link.startsWith("COLE_AQUI")) {
    alert("Adicione o link correto do Google Forms no arquivo app.js.");
    return;
  }

  window.open(link, "_blank", "noopener,noreferrer");
}

/* =========================================
   CADASTRO DOS MEMBROS
   As fotos são arquivos de imagem.
   Instagram aceita URL completa.
========================================= */

const membros = [
  {
    id: 1,
    nome: "Matheus Almeida",
    empresa: "Alfa Construções",
    categoria: "Construção e serviços",
    foto: "assets/fotos/matheus-almeida.jpg",
    logo: "assets/logos/alfa.png",
    instagram: "https://www.instagram.com/USUARIO",
    instagramEmpresa: "https://www.instagram.com/EMPRESA"
  },
  {
    id: 2,
    nome: "Camila Rodrigues",
    empresa: "Floratta Beleza & Bem-estar",
    categoria: "Saúde e bem-estar",
    foto: "assets/fotos/camila-rodrigues.jpg",
    logo: "assets/logos/floratta.png",
    instagram: "https://www.instagram.com/USUARIO",
    instagramEmpresa: "https://www.instagram.com/EMPRESA"
  },
  {
    id: 3,
    nome: "Rafael Santos",
    empresa: "Mecânica do Sul",
    categoria: "Transporte",
    foto: "assets/fotos/rafael-santos.jpg",
    logo: "assets/logos/mecanica.png",
    instagram: "https://www.instagram.com/USUARIO",
    instagramEmpresa: "https://www.instagram.com/EMPRESA"
  },
  {
    id: 4,
    nome: "Juliana Martins",
    empresa: "ArteViva Design",
    categoria: "Marketing e Design",
    foto: "assets/fotos/juliana-martins.jpg",
    logo: "assets/logos/arteviva.png",
    instagram: "https://www.instagram.com/USUARIO",
    instagramEmpresa: "https://www.instagram.com/EMPRESA"
  },
  {
    id: 5,
    nome: "Bruno Ferreira",
    empresa: "Auto Tech",
    categoria: "Automotivo",
    foto: "assets/fotos/bruno-ferreira.jpg",
    logo: "assets/logos/autotech.png",
    instagram: "https://www.instagram.com/USUARIO",
    instagramEmpresa: "https://www.instagram.com/EMPRESA"
  }
];

const categorias = [
  "Todos",
  "Educação",
  "Alimentação",
  "Transporte",
  "Saúde e bem-estar",
  "Construção e serviços",
  "Marketing e Design",
  "Automotivo"
];

let categoriaSelecionada = "Todos";

/* =========================================
   LISTA E FILTROS DE MEMBROS
========================================= */

function renderizarMembros() {
  const lista = document.getElementById("listaMembros");
  const filtros = document.getElementById("filtros");
  const busca = document.getElementById("busca");

  if (!lista || !filtros || !busca) return;

  filtros.innerHTML = "";

  categorias.forEach(categoria => {
    const botao = document.createElement("button");
    botao.className =
      "chip" +
      (categoria === categoriaSelecionada ? " active" : "");

    botao.textContent = categoria;

    botao.onclick = () => {
      categoriaSelecionada = categoria;
      renderizarMembros();
    };

    filtros.appendChild(botao);
  });

  const termo = busca.value.toLowerCase().trim();

  const encontrados = membros.filter(m => {
    const correspondeBusca =
      `${m.nome} ${m.empresa} ${m.categoria}`
        .toLowerCase()
        .includes(termo);

    const correspondeCategoria =
      categoriaSelecionada === "Todos" ||
      m.categoria === categoriaSelecionada;

    return correspondeBusca && correspondeCategoria;
  });

  lista.innerHTML = "";

  if (!encontrados.length) {
    lista.textContent = "Nenhum membro encontrado.";
    return;
  }

  encontrados.forEach(m => {
    const botao = document.createElement("button");
    botao.className = "member";

    const foto = document.createElement("img");
    foto.src = m.foto;
    foto.alt = "Foto de " + m.nome;

    const texto = document.createElement("div");

    const empresa = document.createElement("b");
    empresa.textContent = m.empresa;

    const nome = document.createElement("div");
    nome.className = "name";
    nome.textContent = m.nome;

    const categoria = document.createElement("small");
    categoria.textContent = m.categoria;

    texto.append(empresa, nome, categoria);

    const seta = document.createElement("span");
    seta.className = "arrow";
    seta.textContent = "›";

    botao.append(foto, texto, seta);

    botao.onclick = () => {
      window.location.href = "perfil.html?id=" + m.id;
    };

    lista.appendChild(botao);
  });
}

/* =========================================
   PERFIL DO MEMBRO
   Mostra foto, empresa e Instagrams.
========================================= */

function renderizarPerfil() {
  const area = document.getElementById("perfil");
  if (!area) return;

  const parametros = new URLSearchParams(location.search);
  const id = Number(parametros.get("id"));
  const m = membros.find(item => item.id === id);

  if (!m) {
    area.textContent = "Membro não encontrado.";
    return;
  }

  area.innerHTML = "";

  const foto = document.createElement("img");
  foto.className = "photo";
  foto.src = m.foto;
  foto.alt = "Foto de " + m.nome;
  area.appendChild(foto);

  const nome = document.createElement("h1");
  nome.textContent = m.nome;
  area.appendChild(nome);

  const categoria = document.createElement("p");
  categoria.textContent = m.categoria;
  area.appendChild(categoria);

  if (m.logo) {
    const logo = document.createElement("img");
    logo.className = "company-logo";
    logo.src = m.logo;
    logo.alt = "Logo de " + m.empresa;
    area.appendChild(logo);
  }

  const empresa = document.createElement("h2");
  empresa.textContent = m.empresa;
  area.appendChild(empresa);

  function criarLinkInstagram(texto, url) {
    const link = document.createElement("a");
    link.className = "link";
    link.href = url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";

    const icone = document.createElement("img");
    icone.src = "assets/icons/instagram.svg";
    icone.alt = "Instagram";

    const rotulo = document.createElement("span");
    rotulo.textContent = texto + " ↗";

    link.append(icone, rotulo);
    area.appendChild(link);
  }

  if (m.instagram && !m.instagram.includes("/USUARIO")) {
    criarLinkInstagram("Instagram do membro", m.instagram);
  }

  if (
    m.instagramEmpresa &&
    !m.instagramEmpresa.includes("/EMPRESA")
  ) {
    criarLinkInstagram("Instagram da empresa", m.instagramEmpresa);
  }
}

/* Inicialização das páginas */
renderizarMembros();
renderizarPerfil();
